package com.mycompany;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/servers")
public class ServerController {
    
    @Autowired
    private MongoTemplate mongoTemplate;
    
    @GetMapping("")
    public List<Server> getServers(@RequestParam(required = false) String id) {
        if (id == null) {
            return mongoTemplate.findAll(Server.class);
        } else {
            Server server = mongoTemplate.findById(id, Server.class);
            if (server == null) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND);
            }
            return Collections.singletonList(server);
        }
    }
    
    @PutMapping("create")
    public void createServer(@RequestBody Server server) {
        mongoTemplate.save(server);
    }
    
    @DeleteMapping("/{id}")
    public void deleteServer(@PathVariable String id) {
        Server server = mongoTemplate.findById(id, Server.class);
        if (server == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        mongoTemplate.remove(server);
    }
    
    @GetMapping("/search")
    public List<Server> searchServers(@RequestParam String name) {
        Query query = Query.query(Criteria.where("name").regex(name));
        List<Server> servers = mongoTemplate.find(query, Server.class);
        if (servers.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return servers;
    }
}
